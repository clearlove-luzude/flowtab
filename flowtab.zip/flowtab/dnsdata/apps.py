from django.apps import AppConfig


class DnsdataConfig(AppConfig):
    name = 'dnsdata'
